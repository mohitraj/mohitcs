PyQRCode Tables
***************
.. automodule:: pyqrcode.tables
   :members:
