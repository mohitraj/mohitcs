PyQRCode Module Documentation
*****************************
.. automodule:: pyqrcode
    :members: create, QRCode


