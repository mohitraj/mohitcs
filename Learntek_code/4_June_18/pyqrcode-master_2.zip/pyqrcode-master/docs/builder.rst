PyQRCode Builder Documentation
******************************

.. automodule:: pyqrcode.builder
   :special-members: __init__
   :members:
