#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""\
Runs all tests
"""
import nose

nose.run()
