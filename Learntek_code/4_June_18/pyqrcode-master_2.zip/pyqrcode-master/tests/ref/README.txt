This directory contains QR codes created by other services
(like Google Chart API) which serve as reference images.

The tests in ``test_png.py`` expect a border value of 4 and scale of 6.
